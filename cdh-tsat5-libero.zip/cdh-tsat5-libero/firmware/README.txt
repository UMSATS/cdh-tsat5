Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.9 SP2 (Version 11.9.2.1)

Date    :    Thu Apr 18 15:32:23 2019
Project :    C:\Work\UMSATS\TSAT5\external_rtc_integration\cdh-tsat5\cdh-tsat5-libero
