#ifndef cdh_tsat5_system_HW_PLATFORM_H_
#define cdh_tsat5_system_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Thu Apr 18 15:32:23 2019
*
*Memory map specification for peripherals in cdh_tsat5_system
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Master(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/
#define CORESPI_0_0                     0x50000000U


#endif /* cdh_tsat5_system_HW_PLATFORM_H_*/
